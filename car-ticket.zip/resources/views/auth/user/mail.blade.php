<div>
   Bonjour <b>{{ $name }}</b>,
		<p>{{$body}}</p>
</div>